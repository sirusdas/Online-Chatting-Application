package org.chatapp.constants;

public class AppConstatns {
	
	public static final String CHATMESSAGE ="chatmessage";
	public static final String NEWUSER ="newuser";
	public static final  String GROUPCHATMESSAGE ="groupchatmessage";

}
